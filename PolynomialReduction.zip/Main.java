import java.util.Scanner;
import java.io.*;

public class Main {
    public static void main(String[] args) {
        int nrNoduri, nrMuchii, nrCulori;
        try {
            Scanner scanner = new Scanner(new File("test.in"));
	    BufferedWriter out = new BufferedWriter(new FileWriter("test.out"));		
            nrNoduri = scanner.nextInt();
            nrMuchii = scanner.nextInt();
            nrCulori = scanner.nextInt();
            int nod1,nod2;
            int[][] matrix = new int[nrNoduri][nrNoduri];
	  
 	    //matrice de adiacenta.Se putea folosi pentru economisi memorie
	    //metoda prin liste.
            for(int i=0;i<nrMuchii;i++){
                nod1 = scanner.nextInt();
                nod2 = scanner.nextInt();
                matrix[nod1][nod2]=1;
                matrix[nod2][nod1]=1;
            }
   
	    // string1 va retine expresia : ^ intre toate clauzele de tipul 1 din readme
            String string1 = "";
            for (int i = 0; i < nrNoduri; i++) {
                string1 += "(";
                for (int j = 0; j < nrCulori; j++) {
                    string1 += "x" + (i * nrCulori + j);
                    if (j != nrCulori - 1)
                        string1 += "V";
                }
                string1 += ")";
                if(i!=nrNoduri-1)
                    string1 += "^";
            }
	    
	    // string2 va retine expresia : ^ intre toate clauzele de tipul 2 din readme
            String string2="";
            for(int i=0; i < nrNoduri; i++) {
                for (int j = 0; j < nrCulori; j++) {
                    for (int k = j + 1; k < nrCulori; k++) {
                        string2 += "(" + "~x" + (i * nrCulori + j) + "V" + "~x" + (i * nrCulori + k) + ")";
                        if (!(j == nrCulori - 2 && k == nrCulori - 1 && i==nrNoduri-1))
                            string2 += "^";
                    }
                }
            }

	    // string3 va retine expresia : ^ intre toate clauzele de tipul 3 din readme
            String string3="";
            for(int i = 0; i < nrNoduri; i++) {
                for (int j = i; j < nrNoduri; j++) {
                    if (matrix[i][j] == 1) {
                        for (int k = 0; k < nrCulori; k++) {
                        string3 += "("+"~x"+(i*nrCulori+k)+"V~x"+(j*nrCulori+k)+")^";
                        }
                    }
                }
            }
	    
            //ultimul char din string3 este un ^,deci il stergem(asta daca string3 nu e null)
	    if(string3.length() >= 1)
            	string3 = string3.substring(0,string3.length()-1);
            //punem cele 3 stringuri in vectorul de stringuri parts
	    String[] parts = new String[3];
            parts[0]=string1;
	    parts[1]=string2;
	    parts[2]=string3;
	
  	    //punem ^ intre partile date,in functie de faptul daca exista sau nu
            //(unele din ele pot fi nule)
            
	    String result="";
	    for(int i=0;i<3;i++){
		result += parts[i];
		if(i<=1 && parts[i+1].length()>0)
		 result +="^";
            }
	    //scriem resultatul in fisier	  
            out.write(result);
	    out.close();


        } catch (Exception e) {

        }
    }
}
